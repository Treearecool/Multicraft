alter table `server_config` add `user_ftp` integer not null default 0;
