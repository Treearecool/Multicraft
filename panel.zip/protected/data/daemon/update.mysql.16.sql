create unique index `idx_fus_uq_name` on `ftp_user`(`name`);
