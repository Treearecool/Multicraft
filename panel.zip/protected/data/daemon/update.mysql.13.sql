alter table `server` add `disk_quota` integer not null default 0;
