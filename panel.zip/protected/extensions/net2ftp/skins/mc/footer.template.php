<?php defined("NET2FTP") or die("Direct access to this location is not allowed."); ?>
<!-- Template /skins/mc/footer.php begin -->
	<div id="poweredby" >
		<?php echo Yii::t('mc', "Powered by"); ?> net2ftp<br />
	</div>
</div>
<!-- Template /skins/mc/footer.php end -->
